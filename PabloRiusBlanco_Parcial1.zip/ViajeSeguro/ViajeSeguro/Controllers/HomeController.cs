﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using ViajeSeguro.Models;

namespace ViajeSeguro.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        #region DBInizialicion
        static List<Reserva> ListaReserva = DBTest.IniciateListaReserva();
        private List<Reserva> ReIniciateDB()
        {
            return DBTest.IniciateListaReserva();
        }
        #endregion

        public IActionResult Index()
        {   
            var ListaReserva_last5 = ListaReserva.OrderByDescending(lista => lista.Id).Take(5).ToList();
            return View(new IndexViewModel() { Reservas = ListaReserva_last5 });
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
