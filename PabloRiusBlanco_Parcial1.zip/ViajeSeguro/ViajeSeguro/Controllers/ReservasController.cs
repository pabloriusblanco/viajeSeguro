﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Globalization;
using ViajeSeguro.Models;
using ViajeSeguro.Controllers;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;

namespace ViajeSeguro.Controllers
{
    public class ReservasController : Controller
    {
        #region InyeccionDependenciaHosting
        private readonly IWebHostEnvironment Hosting;
        public ReservasController(IWebHostEnvironment hosting)
        {
            Hosting = hosting;
        }
        #endregion

        #region DBInizialicion
        static List<Reserva> ListaReserva = DBTest.IniciateListaReserva();
        private static List<Reserva> ReIniciateDB()
        {
            return DBTest.IniciateListaReserva();
        }
        #endregion

        #region IndexView
        public IActionResult Index(string CampoOrden, string Codigo, string Apellido, string Precio)
        {
            if( String.IsNullOrEmpty(Codigo) && String.IsNullOrEmpty(Apellido) && String.IsNullOrEmpty(Precio) && String.IsNullOrEmpty(CampoOrden))
            {
                ListaReserva = ReIniciateDB();
                return View(new IndexViewModel() { Reservas = GetListOrderByParam(ListaReserva, CampoOrden) });
            }

            #region CheckeoBusqueda
            if (!(String.IsNullOrEmpty(Codigo)) || !(String.IsNullOrEmpty(Apellido)) || !(String.IsNullOrEmpty(Precio)))
            {
                ListaReserva = FiltrarListaPorBusqueda(Codigo, Apellido, Precio);
            }
            #endregion
        
            return View( new IndexViewModel() { Reservas = GetListOrderByParam(ListaReserva, CampoOrden) });
        }

        public IActionResult BorrarFiltros()
        {
            ListaReserva = ReIniciateDB();
            return RedirectToAction("Index");
        }

        private static List<Reserva> GetListOrderByParam(List<Reserva> ListaTemporal, string Param)
        {
            switch (Param)
            {
                case "Codigo":
                    ListaTemporal = ListaReserva.OrderBy(lista => lista.Codigo).ToList();
                    break;
                case "CodigoDesc":
                    ListaTemporal = ListaReserva.OrderByDescending(lista => lista.Codigo).ToList();
                    break;
                default:
                    ListaTemporal = ListaReserva.OrderByDescending(lista => lista.Codigo).ToList();
                    break;
            }

            return ListaTemporal;
        }

        private static List<Reserva> FiltrarListaPorBusqueda(string Codigo, string Apellido, string Precio)
        {
            if (!(String.IsNullOrEmpty(Codigo)))
            {
                ListaReserva = ListaReserva.Where(lista => lista.Codigo.ToUpper().Contains(Codigo.ToUpper())).ToList();
            }

            if (!(String.IsNullOrEmpty(Apellido)))
            {
                ListaReserva = ListaReserva.Where(lista => lista.Apellido.ToUpper().Contains(Apellido.ToUpper())).ToList();
            }

            if (!(String.IsNullOrEmpty(Precio)))
            {
                if (!Int32.TryParse(Precio, out int parsedPrecio))
                    throw new ArgumentException("Error al parsear.");
                ListaReserva = ListaReserva.Where(lista => lista.Precio.Equals(parsedPrecio)).ToList();
            }

            return ListaReserva;
        }

        #endregion  

        #region Create
        public IActionResult Crear()
        {
            ViewBag.IconosPlanes =  new SelectList(DBTest.IniciateIconosPlanes(), "CodigoIcono", "NombreIcono");
            ViewBag.Regiones = new SelectList(DBTest.IniciateListaRegiones(), "Codigo", "Nombre");
            return View();
        }

        [HttpPost]
        public IActionResult Crear(Reserva ReservaNueva)
        {
            if (ModelState.IsValid)
            {
                if (ValidarRepeticionDeCodigo(ReservaNueva.Codigo)
                    || !DateTime.TryParse(ReservaNueva.FechaIda_string, new CultureInfo("es-ES"), System.Globalization.DateTimeStyles.None, out DateTime fechaIda)
                    || !DateTime.TryParse(ReservaNueva.FechaVuelta_string, new CultureInfo("es-ES"), System.Globalization.DateTimeStyles.None, out DateTime fechaVuelta))
                {
                    ModelState.AddModelError("Codigo", "Hubo un error");
                }
                else
                {
                    ReservaNueva.Origen.Nombre = ReservaNueva.Origen.DisplayName();
                    ReservaNueva.Destino.Nombre = ReservaNueva.Destino.DisplayName();
                    ReservaNueva.QrRuta = GetImageRouteAndSave(ReservaNueva.QR, ReservaNueva.Codigo, "QRs");
                    ReservaNueva.ReciboRuta = GetImageRouteAndSave(ReservaNueva.Recibo, ReservaNueva.Codigo, "receipts");
                    ReservaNueva.DocumentacionRuta = GetImageRouteAndSave(ReservaNueva.Documentacion, ReservaNueva.Codigo, "documentation");
                    ReservaNueva.FechaIda = fechaIda;
                    ReservaNueva.FechaVuelta = fechaVuelta;
                    //INSERT
                    DBTest.InsertReservaToListaReserva(ReservaNueva);
                    return RedirectToAction("Index");
                }
            }

            ViewBag.IconosPlanes = new SelectList(DBTest.IniciateIconosPlanes(), "CodigoIcono", "NombreIcono");
            ViewBag.Regiones = new SelectList(DBTest.IniciateListaRegiones(), "Codigo", "Nombre");
            return View();
        }
        #endregion

        #region Edit
        public IActionResult Editar(string cod)
        {
            Reserva ReservaEncontrada = ListaReserva.Where(x => x.Codigo == cod).FirstOrDefault();
            ViewBag.IconosPlanes = new SelectList(DBTest.IniciateIconosPlanes(), "CodigoIcono", "NombreIcono");
            ViewBag.Regiones = new SelectList(DBTest.IniciateListaRegiones(), "Codigo", "Nombre");
            return View(ReservaEncontrada);
        }

        [HttpPost]
        public IActionResult Editar(Reserva ReservaEditada)
        {
            if (ModelState.IsValid)
            {
                if  (!DateTime.TryParse(ReservaEditada.FechaIda_string, new CultureInfo("es-ES"), System.Globalization.DateTimeStyles.None, out DateTime fechaIda)
                    || !DateTime.TryParse(ReservaEditada.FechaVuelta_string, new CultureInfo("es-ES"), System.Globalization.DateTimeStyles.None, out DateTime fechaVuelta))
                {
                    ModelState.AddModelError("Codigo", "Hubo un error");
                }
                else
                {
                    Reserva ReservaEncontrada = ListaReserva.Where(x => x.Codigo == ReservaEditada.Codigo).FirstOrDefault();

                    #region New Images
                    if (String.IsNullOrEmpty(ReservaEditada.QrRuta) || ReservaEditada.QR != null)
                    {
                        ReservaEditada.QrRuta = GetImageRouteAndSave(ReservaEditada.QR, ReservaEditada.Codigo, "QRs");
                    }
                    if (String.IsNullOrEmpty(ReservaEditada.ReciboRuta) || ReservaEditada.Recibo != null)
                    {
                        ReservaEditada.ReciboRuta = GetImageRouteAndSave(ReservaEditada.Recibo, ReservaEditada.Codigo, "receipts");
                    }
                    if (String.IsNullOrEmpty(ReservaEditada.DocumentacionRuta) || ReservaEditada.Documentacion != null)
                    {
                        ReservaEditada.DocumentacionRuta = GetImageRouteAndSave(ReservaEditada.Documentacion, ReservaEditada.Codigo, "documentation");
                    }
                    #endregion

                    ReservaEditada.FechaIda = fechaIda;
                    ReservaEditada.FechaVuelta = fechaVuelta;                    
                    DBTest.DeleteReservaFromListaReserva(ReservaEncontrada);
                    DBTest.InsertReservaToListaReserva(ReservaEditada);
                    return RedirectToAction("Index");
                }
            }

            ViewBag.IconosPlanes = new SelectList(DBTest.IniciateIconosPlanes(), "CodigoIcono", "NombreIcono");
            ViewBag.Regiones = new SelectList(DBTest.IniciateListaRegiones(), "Codigo", "Nombre");
            return View(ReservaEditada);
        }
        #endregion

        #region Detalles
        public IActionResult Detalle(string cod)
        {
            Reserva ReservaEncontrada = ListaReserva.Where(x => x.Codigo == cod).FirstOrDefault();
            return View(ReservaEncontrada);
        }
        #endregion

        #region Delete
        public IActionResult Eliminar(string cod)
        {
            ListaReserva.Where(x => x.Codigo == cod).FirstOrDefault().Activa = false;
            return RedirectToAction("Index");

            //HardDelete:
            //Reserva ReservaEncontrada = ListaReserva.Where(x => x.Codigo == cod).FirstOrDefault();
            //DBTest.DeleteReservaFromListaReserva(ReservaEncontrada);
        }
        #endregion

        #region ValidateCodeRepetition
        private static bool ValidarRepeticionDeCodigo(string cod)
        {
            return ListaReserva.Exists(x => x.Codigo == cod);
        }
        #endregion

        #region SaveImage
        private string GetImageRouteAndSave(IFormFile Image, string Codigo, string publicFolderName)
        {
            if (Image != null)
            {
                string QRImageName = publicFolderName + "_" + Codigo + "." + Path.GetExtension(Image.FileName).Substring(1);
                string Carpeta = Path.Combine(Hosting.WebRootPath, "images/" + publicFolderName);
                string ImageRouteInDB = "~/images/" + publicFolderName + "/" + QRImageName;
                string RutaDestino = Path.Combine(Carpeta, QRImageName);
                Image.CopyTo(new FileStream(RutaDestino, FileMode.Create));
                return ImageRouteInDB;
            }
            return "";
        }

        #endregion

    }
}
