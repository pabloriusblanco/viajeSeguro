﻿using Microsoft.AspNetCore.Http;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ViajeSeguro.Models
{
    public class Reserva
    {
        #region Id
        [Display(Name = "Id")]
        public int Id { get; set; }
        #endregion

        #region Codigo
        [Display(Name = "Código")]
        [Required(ErrorMessage = "Codigo: Este campo es requerido")]
        [MinLength(4, ErrorMessage = "Codigo: Por favor ingresar como mínimo 4 caracterees")]
        [MaxLength(20, ErrorMessage = "Codigo: Por favor ingresar como máximo 20 caracteres")]
        //[RegularExpression("([a-zA-Z0-9_ .&'-]+)", ErrorMessage = "Por favor ingresar solo caracteres alfanuméricos.")]
        public string Codigo { get; set; }
        #endregion

        #region Apellido
        [Display(Name = "Apellido")]
        [Required(ErrorMessage = "Apellido: Este campo es requerido")]
        [MinLength(1, ErrorMessage = "Apellido: Por favor ingresar como mínimo 1 caracter")]
        [MaxLength(30, ErrorMessage = "Apellido: Por favor ingresar como máximo 30 caracteres")]
        public string Apellido { get; set; }
        #endregion

        #region EstadoPago
        [Display(Name = "Estado Pago")]
        public EstadoPago EstadoPago { get; set; } = EstadoPago.Procesando;
        #endregion

        #region FechaEmision
        public DateTime FechaEmision { get; set; } = DateTime.Now;        
        #endregion

        #region FechaIda
        [Display(Name = "Fecha Ida")]
        public DateTime FechaIda { get; set; }

        [Required(ErrorMessage = "Fecha Inicio: Este campo es requerido")]
        public string FechaIda_string { get; set; }
        #endregion

        #region FechaVuelta
        [Display(Name = "Fecha Vuelta")]
        public DateTime FechaVuelta { get; set; }

        [Required(ErrorMessage = "Fecha Regreso: Este campo es requerido")]
        public string FechaVuelta_string { get; set; }
        #endregion


        #region Plan   
        public Plan Plan { get; set; }
        #endregion

        #region OrigenRegion
        [Display(Name = "Region Origen")]
        [Required(ErrorMessage = "Origen: Este campo es requerido")]
        public Region Origen { get; set; }
        #endregion

        #region DestinoRegion
        [Display(Name = "Region destino")]
        [Required(ErrorMessage = "Destino: Este campo es requerido")]
        public Region Destino { get; set; }
        #endregion

        #region Precio
        [Display(Name = "Precio")]
        [RegularExpression("([1-9][0-9]*)", ErrorMessage = "Precio: Por favor ingresar solo numeros")]
        [Range(1, Int32.MaxValue, ErrorMessage = "Precio: Debe ingresar un numero mayor a 1")]
        public int Precio { get; set; } = 1;
        #endregion

        public bool Activa { get; set; } = true;

        public string QrRuta { get; set; }

        [NotMapped()]
        //[FileExtensions(Extensions = "jpg,png,gif,jpeg,bmp,svg")]
        public IFormFile QR { get; set; }

        public string ReciboRuta { get; set; }

        [NotMapped()]
        //[FileExtensions(Extensions = "jpg,png,gif,jpeg,bmp,svg")]
        public IFormFile Recibo { get; set; }

        public string DocumentacionRuta { get; set; }

        [NotMapped()]
        //[FileExtensions(Extensions = "jpg,png,gif,jpeg,bmp,svg")]
        public IFormFile Documentacion { get; set; }

    }

    public enum EstadoPago
    {
        Procesando,
        Aceptado,
        Rechazado,
    }
}
