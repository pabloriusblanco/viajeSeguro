﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace ViajeSeguro.Models
{
    public class Region
    {
        public string Nombre { get; set; }
        public CodigoRegiones Codigo { get; set; }

        public string DisplayName()
        {
            return this.Codigo.GetType().GetMember(this.Codigo.ToString()).First().GetCustomAttribute<DisplayAttribute>().GetName();
        }
    }

    public enum CodigoRegiones
    {
        [Display(Name = "América del Norte")]
        NA,
        [Display(Name = "Europa")]
        EU,
        [Display(Name = "América Central")]
        CA,
        [Display(Name = "América del Sur")]
        SA,
        [Display(Name = "África")]
        AF,
        [Display(Name = "Asia")]
        AS,
        [Display(Name = "Oceanía")]
        OC
    }
}
